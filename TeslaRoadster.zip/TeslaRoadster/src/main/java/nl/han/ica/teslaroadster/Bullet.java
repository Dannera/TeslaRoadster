package nl.han.ica.teslaroadster;

import nl.han.ica.OOPDProcessingEngineHAN.Collision.ICollidableWithGameObjects;
import nl.han.ica.OOPDProcessingEngineHAN.Objects.GameObject;
import nl.han.ica.OOPDProcessingEngineHAN.Sound.Sound;
import processing.core.PGraphics;
import java.util.List;

/**
 * @author Ralph Niels
 * Bel-klasse
 */
public class Bullet extends GameObject implements ICollidableWithGameObjects{

    private final Sound hitSound;
    private TeslaRoadster world;
    private int bulletSizes;

    /**
     * Constructor
     * @param bubbleSize Afmeting van de bel
     * @param world Referentie naar de wereld
     * @param popSound Geluid dat moet klinken als de bel knapt
     */
    public Bullet(int bulletSizes,TeslaRoadster world,Sound hitSound) {
        this.bulletSizes=bulletSizes;
        this.hitSound=hitSound;
        this.world=world;
        setySpeed(-bulletSizes/10f);
        /* De volgende regels zijn in een zelfgekend object nodig
            om collisiondetectie mogelijk te maken.
         */
        setHeight(bulletSizes);
        setWidth(bulletSizes);
    }

    @Override
    public void update() {
        if (getY() <=100) {
            world.deleteGameObject(this);
        }
    }

    @Override
    public void draw(PGraphics g) {
        g.ellipseMode(g.CORNER); // Omdat cirkel anders vanuit midden wordt getekend en dat problemen geeft bij collisiondetectie
        g.stroke(255, 153, 0, 100);
        g.fill(255, 0, 0, 100);
        g.ellipse(getX(), getY(), bulletSizes, bulletSizes);
    }

    @Override
    public void gameObjectCollisionOccurred(List<GameObject> collidedGameObjects) {
        for (GameObject g:collidedGameObjects) {
            if (g instanceof Roadster) {
                hitSound.rewind();
                hitSound.play();
                world.deleteGameObject(this);
                world.increaseBubblesPopped();
            }
        }
    }
}
