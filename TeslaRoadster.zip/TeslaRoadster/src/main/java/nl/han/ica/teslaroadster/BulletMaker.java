package nl.han.ica.teslaroadster;

import nl.han.ica.OOPDProcessingEngineHAN.Alarm.Alarm;
import nl.han.ica.OOPDProcessingEngineHAN.Alarm.IAlarmListener;
import nl.han.ica.OOPDProcessingEngineHAN.Sound.Sound;

import java.util.Random;

/**
 * @author Ralph Niels
 * Klasse die Bubbles aanmaakt met configureerbare
 * snelheid.
 */
public class BulletMaker implements IAlarmListener {

    private float hitsPerSecond;
    private Random random;
    private TeslaRoadster world;
    private Sound hitSound;

    /** Constructor
     * @param world Referentie naar de wereld
     * @param popSound Geluid dat moet klinken als een bel knapt
     * @param bubblesPerSecond Aantal bellen dat per seconden gemaakt moet worden
     */
    public BulletMaker(TeslaRoadster world,Sound hitSound,float hitsPerSecond) {
        this.hitsPerSecond=hitsPerSecond;
        this.world=world;
        this.hitSound=hitSound;
        random=new Random();
        startAlarm();
    }

    private void startAlarm() {
        Alarm alarm=new Alarm("New bullet",1/hitsPerSecond);
        alarm.addTarget(this);
        alarm.start();
    }

    @Override
    public void triggerAlarm(String alarmName) {
    		int bulletSizes=random.nextInt(10) + 10;
        Bullet b=new Bullet(bulletSizes,world,hitSound);
        world.addGameObject(b, random.nextInt(world.getWidth()), world.getHeight());
        startAlarm();
    }

}
