package nl.han.ica.teslaroadster;

import nl.han.ica.OOPDProcessingEngineHAN.Objects.AnimatedSpriteObject;
import nl.han.ica.OOPDProcessingEngineHAN.Objects.Sprite;
import nl.han.ica.OOPDProcessingEngineHAN.Objects.SpriteObject;

public class Meteoroid extends SpriteObject implements Obstacle {

	  private TeslaRoadster world;

	    /**
	     * Constructor
	     * @param world Referentie naar de wereld
	     */
	    public Meteoroid(TeslaRoadster world) {
	        this(new Sprite("src/main/java/nl/han/ica/teslaroadster/media/meteoroid1.gif"));
	        this.world=world;
	    }

	    /**
	     * Maak een Swordfish aan met een sprite
	     * @param sprite De sprite die aan dit object gekoppeld moet worden
	     */
	    private Meteoroid(Sprite sprite) {
	        super(sprite);
	        setxSpeed(-1);
	    }

	    @Override
	    public void update() {
	        if (getX()+getWidth()<=0) {
	            setX(world.getWidth());
	            
	        }

	    }
	    
    public void draw() {
	    	
	    }
	    
}