package nl.han.ica.teslaroadster;

public interface Obstacle {
	
	void draw();

}
