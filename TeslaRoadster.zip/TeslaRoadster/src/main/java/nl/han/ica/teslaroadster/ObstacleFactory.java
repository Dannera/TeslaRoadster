package nl.han.ica.teslaroadster;

public class ObstacleFactory{
	
	public ObstacleFactory() {
		// TODO Auto-generated constructor stub
	}
	
	
	
	   //use getObstacle method to get object of type obstacle 
	   public Obstacle getObstacle(String obstacleType){
	      if(obstacleType == null){
	         return null;
	      }		
	      if(obstacleType.equalsIgnoreCase("Alien")){
	         return new Alien(null);
	         
	      } else if(obstacleType.equalsIgnoreCase("Astroid")){
	         return new Asteroid(null);
	         
	      } else if(obstacleType.equalsIgnoreCase("Meteoroid")){
	         return new Meteoroid(null);
	      }
	      
	      return null;
	   }
	   


}
