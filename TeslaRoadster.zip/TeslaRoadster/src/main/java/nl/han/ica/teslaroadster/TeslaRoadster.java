package nl.han.ica.teslaroadster;

import nl.han.ica.OOPDProcessingEngineHAN.Dashboard.Dashboard;
import nl.han.ica.OOPDProcessingEngineHAN.Engine.GameEngine;
import nl.han.ica.OOPDProcessingEngineHAN.Objects.Sprite;
import nl.han.ica.OOPDProcessingEngineHAN.Persistence.FilePersistence;
import nl.han.ica.OOPDProcessingEngineHAN.Persistence.IPersistence;
import nl.han.ica.OOPDProcessingEngineHAN.Sound.Sound;
import nl.han.ica.OOPDProcessingEngineHAN.Tile.TileMap;
import nl.han.ica.OOPDProcessingEngineHAN.Tile.TileType;
import nl.han.ica.OOPDProcessingEngineHAN.View.EdgeFollowingViewport;
import nl.han.ica.OOPDProcessingEngineHAN.View.View;
import nl.han.ica.teslaroadster.BulletMaker;
import nl.han.ica.teslaroadster.Player;
import nl.han.ica.teslaroadster.Roadster;
import nl.han.ica.teslaroadster.TextObject;
import nl.han.ica.teslaroadster.tiles.BoardsTile;
import processing.core.PApplet;

@SuppressWarnings("serial")
public class TeslaRoadster extends GameEngine{
	
	
    private Sound backgroundSound;
    private Sound bulletHitSound;
    private TextObject dashboardText;
    private BulletMaker bulletMaker;
    private int bubblesPopped;
    private IPersistence persistence;
    private Player player;

	public TeslaRoadster() {
		// TODO Auto-generated constructor stub
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PApplet.main(new String[]{"nl.han.ica.teslaroadster.TeslaRoadster"});
	}

	@Override
	public void setupGame() {
		// TODO Auto-generated method stub
		    int worldWidth=1204;
	        int worldHeight=903;

	        initializeSound();
	        createDashboard(worldWidth, 100);
	        initializeTileMap();
	        initializePersistence();

	        createObjects();
	        createBubbleSpawner();

	        createViewWithoutViewport(worldWidth, worldHeight);
	        //createViewWithViewport(worldWidth, worldHeight, 800, 800, 1.1f);
		
	}

    /**
     * Creeërt de view zonder viewport
     * @param screenWidth Breedte van het scherm
     * @param screenHeight Hoogte van het scherm
     */
    private void createViewWithoutViewport(int screenWidth, int screenHeight) {
        View view = new View(screenWidth,screenHeight);
        view.setBackground(loadImage("src/main/java/nl/han/ica/teslaroadster/media/background.gif"));

        setView(view);
        size(screenWidth, screenHeight);
    }

    /**
     * Creeërt de view met viewport
     * @param worldWidth Totale breedte van de wereld
     * @param worldHeight Totale hoogte van de wereld
     * @param screenWidth Breedte van het scherm
     * @param screenHeight Hoogte van het scherm
     * @param zoomFactor Factor waarmee wordt ingezoomd
     */
    private void createViewWithViewport(int worldWidth,int worldHeight,int screenWidth,int screenHeight,float zoomFactor) {
        EdgeFollowingViewport viewPort = new EdgeFollowingViewport(player, (int)Math.ceil(screenWidth/zoomFactor),(int)Math.ceil(screenHeight/zoomFactor),0,0);
        viewPort.setTolerance(50, 50, 50, 50);
        View view = new View(viewPort, worldWidth,worldHeight);
        setView(view);
        size(screenWidth, screenHeight);
        view.setBackground(loadImage("src/main/java/nl/han/ica/teslaroadster/media/background.gif"));
    }

    /**
     * Initialiseert geluid
     */
    private void initializeSound() {
        backgroundSound = new Sound(this, "src/main/java/nl/han/ica/teslaroadster/media/teslaRoadster.mp3");
        backgroundSound.loop(-1);
        bulletHitSound = new Sound(this, "src/main/java/nl/han/ica/teslaroadster/media/pop.mp3");
    }


    /**
     * Maakt de spelobjecten aan
     */
    private void createObjects() {
        player = new Player(this);
        addGameObject(player, 100, 100);
        Roadster sf=new Roadster(this);
        addGameObject(sf,200,200);
        
        //Alien
        Alien alien = new Alien(this);
        addGameObject(alien,400,400);
        
        //Meteoroid
        Meteoroid meteoroid = new Meteoroid(this);
        addGameObject(meteoroid,100,100);
        
        
        //Astroid
        Asteroid asteroid = new Asteroid(this);
        addGameObject(asteroid,150,150);
        
        
        //ObstacleFactory
     //   ObstacleFactory obstacleFactory = new ObstacleFactory();
       // Obstacle meteoroid = obstacleFactory.getObstacle("Meteoroid");
       // addGameObject(meteoroid,300,300);

    }

    /**
     * Maakt de spawner voor de bellen aan
     */
    public void createBubbleSpawner() {
        bulletMaker=new BulletMaker(this,bulletHitSound,2);
    }

    /**
     * Maakt het dashboard aan
     * @param dashboardWidth Gewenste breedte van dashboard
     * @param dashboardHeight Gewenste hoogte van dashboard
     */
    private void createDashboard(int dashboardWidth,int dashboardHeight) {
        Dashboard dashboard = new Dashboard(0,0, dashboardWidth, dashboardHeight);
        dashboardText=new TextObject("");
        dashboard.addGameObject(dashboardText);
        addDashboard(dashboard);
    }

    /**
     * Initialiseert de opslag van de bellenteller
     * en laadt indien mogelijk de eerder opgeslagen
     * waarde
     */
    private void initializePersistence() {
        persistence = new FilePersistence("main/java/nl/han/ica/teslaroadster/media/bubblesPopped.txt");
        if (persistence.fileExists()) {
            bubblesPopped = Integer.parseInt(persistence.loadDataString());
            refreshDasboardText();
        }
    }

    /** 
     * Initialiseert de tilemap
     */
    private void initializeTileMap() {
        /* TILES */
        Sprite boardsSprite = new Sprite("src/main/java/nl/han/ica/waterworld/media/boards.jpg");
        TileType<BoardsTile> boardTileType = new TileType<>(BoardsTile.class, boardsSprite);

        TileType[] tileTypes = { boardTileType };
        int tileSize=50;
        int tilesMap[][]={
                {-1,-1,-1,-1,-1,-1,-1,-1,-1,-1},
                {-1,-1,-1,-1,-1,-1,-1,-1,-1,-1},
                {-1,-1,-1,-1,-1,-1,-1,-1,-1,-1},
                {-1,-1,-1,-1,-1,-1,-1,-1,-1,-1},
                {-1,-1,-1,-1,-1,-1,-1,-1,-1,-1},
                {-1,-1,-1,-1,-1,-1,-1,-1,-1,-1},
                {-1,-1,-1,-1,-1,-1,-1,-1,-1,-1},
                {-1,-1,-1,-1,-1,-1,-1,-1,-1,-1},
                {-1,-1,-1,-1,-1,-1,-1,-1,-1,-1},
                {-1,-1,-1, 0, 0, 0, 0,-1,0 , 0},
                {-1,-1,-1,-1,-1,-1,-1,-1,-1,-1},
                {-1,-1,-1,-1,-1,-1,-1,-1,-1,-1},
                {-1,-1,-1,-1,-1,-1,-1,-1,-1,-1},
                {-1,-1,-1,-1,-1,-1,-1,-1,-1,-1}
        };
        tileMap = new TileMap(tileSize, tileTypes, tilesMap);
    }

    @Override
    public void update() {
    }

    /**
     * Vernieuwt het dashboard
     */
    private void refreshDasboardText() {
        dashboardText.setText("Bullet hits: "+bubblesPopped);
    }

    /**
     * Verhoogt de teller voor het aantal
     * geknapte bellen met 1
     */
    public void increaseBubblesPopped() {
        bubblesPopped++;
        persistence.saveData(Integer.toString(bubblesPopped));
        refreshDasboardText();
    }

}
